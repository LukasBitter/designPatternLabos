#pragma once
#include "Component.h"

class CLeaf :
	public CComponent
{
public:
	CLeaf() {};
	virtual ~CLeaf() {};
};
